﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RamonSilva.Aula03.Model
{
    public enum TipoLogradouro
    {
        Aeroporto, Alameda, Avenida, Beco, Bloco,
        Caminho, Condominio, Estacao, Estrada, Fazenda, Fortaleza, Galeria,
        Ladeira, Largo, Praca, Praia, Quadra, Quilometro, Quinta,
        Rodovia, Rua, Travessa, Viaduto, Vila
    }
}
